# Which version numbering system does Composer itself use?

Composer uses [Semantic Versioning (aka SemVer)
2.0.0](https://semver.org/spec/v2.0.0.html).
